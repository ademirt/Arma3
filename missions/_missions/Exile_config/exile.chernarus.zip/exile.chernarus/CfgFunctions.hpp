class CfgFunctions 
{
	class RG_Client_Core 
	{	
		tag = "exile";
		class Functions
		{
			file = "core\functions";
			class Statusbar {};
		};
	};
};